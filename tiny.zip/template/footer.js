footer_template={'html':'\
<div class="footer_info"><%=footer%></div>\
'};