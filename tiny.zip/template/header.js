header_template={'html':'\
<div class="header_title"><h1><a href="http://<%=domain%>"><%=title%></a></h1></div> \
<div class="header_description"><h2><%=description%></h2></div> \
'};