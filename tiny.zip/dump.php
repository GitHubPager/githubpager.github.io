<?php
print($_POST['content']);
?>